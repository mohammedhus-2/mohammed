
// تحسينات الأمان والمصادقة في backend.js
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(express.json());

// تطبيق محددات طلبات API لمنع الهجمات العنيفة
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 5, // حد أقصى 5 محاولات تسجيل دخول كل 15 دقيقة
    message: "عدد كبير جدًا من المحاولات. الرجاء المحاولة لاحقًا."
});

// نظام مصادقة محسن
app.post('/login', loginLimiter, async (req, res) => {
    const { username, password } = req.body;

    // جلب المستخدم من قاعدة البيانات (يجب استبدالها بقاعدة بيانات فعلية)
    const user = { username: "admin", passwordHash: "$2b$10$Q.Td7nYt6i2aW/jUp5XfBuvvKX5Rq1RhvZG9TzEoM95fwZjVb1b7m" }; 

    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
        return res.status(401).json({ message: "بيانات الاعتماد غير صحيحة" });
    }

    // إنشاء رمز JWT
    const token = jwt.sign({ username: user.username }, "secret_key", { expiresIn: '1h' });
    res.json({ token });
});

app.listen(3000, () => console.log("الخادم يعمل على المنفذ 3000"));
